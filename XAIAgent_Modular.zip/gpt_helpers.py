
import openai
import os
import random
import logging
from post_utils import is_duplicate_tweet
from news_fetcher import get_random_headline, extract_ticker_from_headline

openai.api_key = os.getenv("OPENAI_API_KEY")

def generate_gpt_tweet(prompt=None):
    hashtags = ["#Web3", "#Ethereum", "#DeFi", "#OnChain", "#Crypto", "#Layer2", "#zk"]

    # Use news-based dynamic prompt if none provided
    if prompt is None:
        headline, _ = get_random_headline()
        if headline:
            ticker = extract_ticker_from_headline(headline)
            prompt = f"Write a short, insightful tweet reacting to this crypto news headline: '{headline}'. Include opinion and optionally the token ${ticker}."
        else:
            prompt = "Write a short tweet about Web3 or crypto."

    if random.random() < 0.6:
        prompt += f" Include the hashtag {random.choice(hashtags)}."

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[
                {"role": "system", "content": (
                    "You are a witty, insightful Web3 influencer. "
                    "Write clever, sharp tweets with confidence, humor, or insight."
                )},
                {"role": "user", "content": prompt}
            ],
            max_tokens=64,
            temperature=1.0
        )
        return response['choices'][0]['message']['content'].strip()
    except Exception as e:
        logging.error(f"GPT generation failed: {e}")
        return "The future is on-chain. #Web3"

def generate_unique_gpt_tweet(prompt, max_attempts=5):
    for _ in range(max_attempts):
        tweet = generate_gpt_tweet(prompt)
        if not is_duplicate_tweet(tweet):
            return tweet
    return "The future is modular. #Web3"

def generate_news_thread(headline, ticker, url):
    intro = f"*** Daily Dobie Crypto Update ***\n\n📰 Headline: {headline}\n📈 Token: ${ticker}\n🧠 Summary: Here's what it means — 🧵"
    prompt = (
        f"Write a 3-part Twitter thread analyzing this crypto headline: '{headline}'. "
        f"The related token is ${ticker}. Each part must be < 280 characters and should explain the context, give an opinion, and include a final insight."
    )

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[
                {"role": "system", "content": (
                    "You are a sharp Web3 analyst who explains news clearly and briefly in thread format."
                )},
                {"role": "user", "content": prompt}
            ],
            max_tokens=800,
            temperature=0.9
        )

        body_parts = [p.strip() for p in response['choices'][0]['message']['content'].split('\n') if p.strip()]
        if len(body_parts) < 2:
            return []

        body_parts.append(f"🔗 Read more: {url}")
        return [intro] + body_parts
    except Exception as e:
        logging.error(f"GPT news thread generation failed: {e}")
        return []
