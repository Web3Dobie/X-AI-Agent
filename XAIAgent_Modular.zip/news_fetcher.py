
import feedparser
import random
import logging

RSS_FEEDS = [
    "https://www.coindesk.com/arc/outboundfeeds/rss/",
    "https://decrypt.co/feed",
    "https://cointelegraph.com/rss"
]

def fetch_headlines(limit=5):
    headlines = []
    for url in RSS_FEEDS:
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:limit]:
                headlines.append((entry.title, entry.link))
        except Exception as e:
            logging.warning(f"Failed to parse RSS: {url} - {e}")
    return headlines

def get_random_headline():
    headlines = fetch_headlines()
    if not headlines:
        return None, None
    return random.choice(headlines)

def extract_ticker_from_headline(headline):
    ticker_map = {
        "bitcoin": "BTC", "btc": "BTC",
        "ethereum": "ETH", "eth": "ETH",
        "solana": "SOL", "sol": "SOL",
        "avalanche": "AVAX", "avax": "AVAX",
        "arbitrum": "ARB", "arb": "ARB",
        "optimism": "OP", "op": "OP",
        "polygon": "MATIC", "matic": "MATIC"
    }
    for keyword, ticker in ticker_map.items():
        if keyword in headline.lower():
            return ticker
    return "CRYPTO"
