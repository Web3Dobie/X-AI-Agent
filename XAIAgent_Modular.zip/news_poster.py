
import logging
from news_fetcher import get_random_headline, extract_ticker_from_headline
from gpt_helpers import generate_news_thread
from post_utils import log_tweet, client

def post_news_thread():
    try:
        headline, url = get_random_headline()
        if not headline:
            logging.warning("No headlines available — skipping news thread.")
            return

        ticker = extract_ticker_from_headline(headline)
        parts = generate_news_thread(headline, ticker, url)

        if not parts or len(parts) < 2:
            logging.warning("Generated thread was too short — skipping.")
            return

        # Post full thread
        first = client.create_tweet(text=parts[0])
        log_tweet(first.data['id'], parts[0], "news_thread")
        reply_id = first.data['id']

        for part in parts[1:]:
            reply = client.create_tweet(text=part, in_reply_to_tweet_id=reply_id)
            reply_id = reply.data['id']

        logging.info(f"✅ Posted news thread: {headline}")

    except Exception as e:
        logging.error(f"❌ Failed to post news thread: {e}")
