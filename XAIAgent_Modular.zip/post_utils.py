
import csv
import time
import logging
from datetime import datetime, timezone
from difflib import SequenceMatcher
import tweepy
from gpt_helpers import generate_unique_gpt_tweet

client = None  # To be assigned in scheduler

def log_tweet(tweet_id, content, category="general"):
    with open("logs/tweet_log.csv", mode="a", newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        if file.tell() == 0:
            writer.writerow(["tweet_id", "content", "category", "timestamp"])
        writer.writerow([tweet_id, content, category, datetime.now(timezone.utc).isoformat()])

def is_duplicate_tweet(new_text, threshold=0.85):
    try:
        with open("logs/tweet_log.csv", newline='', encoding='utf-8') as f:
            reader = list(csv.DictReader(f))[-20:]
            for row in reader:
                similarity = SequenceMatcher(None, new_text.lower(), row["content"].lower()).ratio()
                if similarity > threshold:
                    logging.warning(f"⚠️ Skipping duplicate tweet (similarity {similarity:.2f})")
                    return True
    except FileNotFoundError:
        pass
    return False

def post_original_tweet():
    tweet = generate_unique_gpt_tweet("Write a punchy Web3 tweet.")
    if is_duplicate_tweet(tweet):
        return
    res = client.create_tweet(text=tweet)
    log_tweet(res.data['id'], tweet, "original")
    logging.info(f"✅ Posted original: {tweet}")

def post_quote_tweet():
    tweet = generate_unique_gpt_tweet("Write a clever quote tweet about a current Web3 topic.")
    if is_duplicate_tweet(tweet):
        return
    res = client.create_tweet(text=tweet)
    log_tweet(res.data['id'], tweet, "quote")
    logging.info(f"✅ Posted quote: {tweet}")

def post_reply_to_kol():
    tweet = generate_unique_gpt_tweet("Write a smart reply to a crypto influencer tweet.")
    if is_duplicate_tweet(tweet):
        return
    res = client.create_tweet(text=f"(AI reply style): {tweet}")
    log_tweet(res.data['id'], tweet, "reply")
    logging.info(f"✅ Posted reply: {tweet}")

def post_thread():
    from openai import ChatCompletion
    import openai
    import os
    openai.api_key = os.getenv("OPENAI_API_KEY")

    prompt = "Write a 3-part educational Web3 Twitter thread. Each part should be under 280 characters."
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[
                {"role": "system", "content": "You write clear, insightful Web3 Twitter threads."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=512,
            temperature=0.9
        )
        content = response['choices'][0]['message']['content']
        parts = [p.strip() for p in content.split('\n') if p.strip()]
        if len(parts) < 2:
            logging.warning("Thread too short, skipping.")
            return

        first = client.create_tweet(text=parts[0])
        log_tweet(first.data['id'], parts[0], "thread")
        reply_id = first.data['id']
        for p in parts[1:]:
            reply = client.create_tweet(text=p, in_reply_to_tweet_id=reply_id)
            reply_id = reply.data['id']

        logging.info(f"✅ Thread posted: {len(parts)} tweets")
    except Exception as e:
        logging.error(f"❌ Error posting thread: {e}")

def reply_to_comments(bot_id):
    try:
        with open("logs/tweet_log.csv", newline='', encoding='utf-8') as f:
            tweets = list(csv.DictReader(f))[-5:]
    except FileNotFoundError:
        logging.warning("No tweet log found — skipping replies.")
        return

    for t in tweets:
        tweet_id = t["tweet_id"]
        try:
            query = f"conversation_id:{tweet_id} is:reply"
            replies = client.search_recent_tweets(query=query, tweet_fields=["author_id", "text"], max_results=10)
            if not replies.data:
                continue

            for r in replies.data:
                if str(r.author_id) == bot_id:
                    continue
                prompt = f"Write a friendly, witty reply to this tweet: {r.text}"
                reply_text = generate_unique_gpt_tweet(prompt)

                if is_duplicate_tweet(reply_text):
                    continue

                client.create_tweet(text=reply_text, in_reply_to_tweet_id=r.id)
                log_tweet(r.id, reply_text, "comment_reply")
                logging.info(f"✅ Replied to comment under {tweet_id}: {reply_text}")
                break
        except Exception as e:
            logging.error(f"❌ Error replying under tweet {tweet_id}: {e}")
