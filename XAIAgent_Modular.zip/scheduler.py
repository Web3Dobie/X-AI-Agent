
import os
import time
import logging
import schedule
from datetime import datetime, timedelta, timezone
from dotenv import load_dotenv
import tweepy

from post_utils import post_original_tweet, post_quote_tweet, post_reply_to_kol, post_thread, reply_to_comments, client as utils_client
from news_poster import post_news_thread

# === Load environment variables ===
load_dotenv()

# === Logging Setup ===
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    filename='logs/activity.log',
    level=logging.INFO,
    format='%(asctime)s - %(message)s'
)

# === Tweepy client setup ===
client = tweepy.Client(
    bearer_token=os.getenv("BEARER_TOKEN"),
    consumer_key=os.getenv("API_KEY"),
    consumer_secret=os.getenv("API_SECRET"),
    access_token=os.getenv("ACCESS_TOKEN"),
    access_token_secret=os.getenv("ACCESS_TOKEN_SECRET")
)

# Assign the client to post_utils module
utils_client = client

# === Engagement & Dynamic Posting ===
def calculate_daily_engagement():
    try:
        today = datetime.now(timezone.utc).date()
        yesterday = today - timedelta(days=1)
        with open("logs/performance_log.csv", newline='', encoding='utf-8') as f:
            import csv
            reader = csv.DictReader(f)
            score = sum(
                int(r["likes"]) + int(r["retweets"]) + int(r["replies"])
                for r in reader if r["timestamp"].startswith(str(yesterday))
            )
        with open("logs/dynamic_schedule.txt", "w") as f:
            f.write(str(score))
        logging.info(f"📊 Engagement score for {yesterday}: {score}")
    except Exception as e:
        logging.error(f"❌ Engagement calc error: {e}")

def post_dynamic():
    try:
        with open("logs/dynamic_schedule.txt") as f:
            score = int(f.read().strip())
    except:
        score = 0

    logging.info(f"📈 Dynamic post schedule triggered with score {score}")

    if score >= 30:
        post_original_tweet()
        time.sleep(3600)
        post_quote_tweet()
        time.sleep(3600)
        post_reply_to_kol()
        time.sleep(3600)
        post_thread()
    elif score >= 10:
        post_original_tweet()
        time.sleep(3600)
        post_quote_tweet()
        time.sleep(3600)
        post_reply_to_kol()
    else:
        post_original_tweet()
        time.sleep(3600)
        post_reply_to_kol()

# === Schedule Tasks ===
schedule.every().day.at("07:00").do(calculate_daily_engagement)
schedule.every().day.at("08:00").do(post_news_thread)
schedule.every().day.at("10:00").do(post_dynamic)
schedule.every().day.at("18:00").do(lambda: reply_to_comments(bot_id=os.getenv("BOT_USER_ID")))

# === Run Loop ===
print("🤖 Smart X Agent is running...")
while True:
    schedule.run_pending()
    time.sleep(60)
