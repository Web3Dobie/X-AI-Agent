import logging
from gpt_helpers import generate_market_summary_thread
from post_utils import post_tweet
from tweet_limit_guard import has_reached_daily_limit

def post_market_summary_thread():
    if has_reached_daily_limit():
        logging.warning("🚫 Daily tweet limit reached — skipping market summary.")
        return

    thread_parts = generate_market_summary_thread()
    if not thread_parts or len(thread_parts) == 0:
        logging.warning("⚠️ No market summary thread generated.")
        return

    try:
        first = post_tweet(thread_parts[0], "Thread")
        if not first:
            return
        reply_id = first

        for p in thread_parts[1:]:
            from post_utils import client
            res = client.create_tweet(text=p, in_reply_to_tweet_id=reply_id)
            reply_id = res.data['id']
            logging.info(f"↳ Market thread part: {p}")

        logging.info("📊 Posted market summary thread successfully.")
    except Exception as e:
        logging.error(f"❌ Error posting market summary thread: {e}")

def generate_market_summary_thread():
    tokens = get_top_tokens_data()
    token_lines = [f"- ${t['symbol']}: ${t['price']:.2f} ({t['change']:+.2f}%)" for t in tokens]
    prompt = (
        "Write a 5-part tweet thread summarizing the market conditions for these tokens:\n" +
        "\n".join(token_lines) +
        "\nEach tweet should be short, crypto-native, and under 280 characters. Prefix with 1/5, 2/5, etc."
    )

    try:
        response = gpt_client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a crypto commentator writing short tweet threads."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=600,
            temperature=0.85
        )
        return [p.strip() for p in response.choices[0].message.content.strip().split("\n") if p.strip()]
    except Exception as e:
        logging.error(f"❌ Error generating market summary thread: {e}")
        return []